package Model;

/**
 * Enumerateur de tout les programmes
 * @author Noe Lecointe
 * @author Wang Zezhong
 */
public enum Programmes {
	ISI, RT, A2I, GI, GM, MTE, MM;
}
