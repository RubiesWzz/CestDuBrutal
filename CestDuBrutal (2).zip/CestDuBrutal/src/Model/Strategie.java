package Model;

/**
 * Enumerateur de toute les strategies
 * @author Noe Lecointe
 * @author Wang Zezhong
 */
public enum Strategie {
	defensive, offensive, aleatoire;
}
